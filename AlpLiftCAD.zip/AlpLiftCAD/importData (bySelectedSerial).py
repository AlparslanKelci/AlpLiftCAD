import sqlite3
import os

con = sqlite3.connect(os.environ['APPDATA'] + '\\AlpLiftCad\\ASNdata.db')
cur = con.cursor()



asnSeriNo = "1440"

cur.execute("SELECT YAPI_SAHIBI FROM asn WHERE ASN_SERI_NO=" + "\'" + asnSeriNo + "\'")
yapıSah = cur.fetchone()[0]

cur.execute("SELECT ADRES FROM asn WHERE ASN_SERI_NO=" + "\'" + asnSeriNo + "\'")
adres = cur.fetchone()[0]

cur.execute("SELECT MUTEAHHIT FROM asn WHERE ASN_SERI_NO=" + "\'" + asnSeriNo + "\'")
müteahhit = cur.fetchone()[0]

cur.execute("SELECT KULLANIM_AMACI FROM asn WHERE ASN_SERI_NO=" + "\'" + asnSeriNo + "\'")
kullanım = cur.fetchone()[0]

cur.execute("SELECT BELEDIYE FROM asn WHERE ASN_SERI_NO=" + "\'" + asnSeriNo + "\'")
bel = cur.fetchone()[0]

cur.execute("SELECT IL FROM asn WHERE ASN_SERI_NO=" + "\'" + asnSeriNo + "\'")
il = cur.fetchone()[0]

cur.execute("SELECT MAHALLE FROM asn WHERE ASN_SERI_NO=" + "\'" + asnSeriNo + "\'")
mah = cur.fetchone()[0]

cur.execute("SELECT CAD_SK FROM asn WHERE ASN_SERI_NO=" + "\'" + asnSeriNo + "\'")
cadSk = cur.fetchone()[0]

cur.execute("SELECT NO FROM asn WHERE ASN_SERI_NO=" + "\'" + asnSeriNo + "\'")
no = cur.fetchone()[0]

cur.execute("SELECT PAFTA FROM asn WHERE ASN_SERI_NO=" + "\'" + asnSeriNo + "\'")
pafta = cur.fetchone()[0]

cur.execute("SELECT ADA FROM asn WHERE ASN_SERI_NO=" + "\'" + asnSeriNo + "\'")
ada = cur.fetchone()[0]

cur.execute("SELECT PARSEL FROM asn WHERE ASN_SERI_NO=" + "\'" + asnSeriNo + "\'")
parsel = cur.fetchone()[0]

cur.execute("SELECT MAK_DAIRESI FROM asn WHERE ASN_SERI_NO=" + "\'" + asnSeriNo + "\'")
makDairesi = cur.fetchone()[0]

cur.execute("SELECT HIZ FROM asn WHERE ASN_SERI_NO=" + "\'" + asnSeriNo + "\'")
hız = cur.fetchone()[0]

cur.execute("SELECT SEYIR_MESAFESI FROM asn WHERE ASN_SERI_NO=" + "\'" + asnSeriNo + "\'")
seyir = str(int(cur.fetchone()[0])/1000).replace(".",",")

cur.execute("SELECT KABIN_GENISLIGI FROM asn WHERE ASN_SERI_NO=" + "\'" + asnSeriNo + "\'")
kabGen = cur.fetchone()[0]

cur.execute("SELECT KABIN_DERINLIGI FROM asn WHERE ASN_SERI_NO=" + "\'" + asnSeriNo + "\'")
kabDer = cur.fetchone()[0]

cur.execute("SELECT RAY_KAPI FROM asn WHERE ASN_SERI_NO=" + "\'" + asnSeriNo + "\'")
rayKapı = cur.fetchone()[0]

cur.execute("SELECT KUYU_BOYU FROM asn WHERE ASN_SERI_NO=" + "\'" + asnSeriNo + "\'")
kuyuBoyu = str(int(cur.fetchone()[0])/1000).replace(".",",")

cur.execute("SELECT MOTOR_GUCU FROM asn WHERE ASN_SERI_NO=" + "\'" + asnSeriNo + "\'")
motGüç = cur.fetchone()[0]

cur.execute("SELECT DURAK_SAYISI_UST FROM asn WHERE ASN_SERI_NO=" + "\'" + asnSeriNo + "\'")
durSayÜst = cur.fetchone()[0]

cur.execute("SELECT DURAK_SAYISI_ALT FROM asn WHERE ASN_SERI_NO=" + "\'" + asnSeriNo + "\'")
durSayAlt = cur.fetchone()[0]

cur.execute("SELECT DB_DATE FROM asn WHERE ASN_SERI_NO=" + "\'" + asnSeriNo + "\'")
date = cur.fetchone()[0]

cur.execute("SELECT KAPASITE FROM asn WHERE ASN_SERI_NO=" + "\'" + asnSeriNo + "\'")
kapasite = cur.fetchone()[0]

cur.execute("SELECT MOTOR_TIPI FROM asn WHERE ASN_SERI_NO=" + "\'" + asnSeriNo + "\'")
motTip = cur.fetchone()[0]

# Define templateFile for AsnHesap veriler.txt
templateFile = os.environ['APPDATA'] + "\\AsnHesap\\veriler.txt"

if "6 Kişi" and "450 KG" in kapasite:
    templateFile = os.environ['APPDATA'] + "\\AsnHesap\\alp\\Veriler - 6 Kişi 450 KG Dişlili.txt"
if "8 kişi" and "630 KG" in kapasite:
    templateFile = os.environ['APPDATA'] + "\\AsnHesap\\alp\\Veriler - 8 Kişi 630 KG Dişlili.txt"
if "10 kişi" and "800 KG" in kapasite:
    templateFile = os.environ['APPDATA'] + "\\AsnHesap\\alp\\Veriler - 10 Kişi 800 KG Dişlili.txt"
if "12 kişi" and "1200 KG" in kapasite:
    templateFile = os.environ['APPDATA'] + "\\AsnHesap\\alp\\Veriler - 12 Kişi 1200 KG Dişlilli"
if "17 kişi" and "1275 KG" in kapasite:
    templateFile = os.environ['APPDATA'] + "\\AsnHesap\\alp\\Veriler - 17 Kişi 1275 KG Dişlili (ZF 102).txt"

if "8 kişi" and "630 KG" in kapasite and "DİŞLİSİZ" in motTip:
    templateFile = os.environ['APPDATA'] + "\\AsnHesap\\alp\\Veriler - 8 Kişi 630 KG Dişlilisiz.txt"
if "10 kişi" and "800 KG" in kapasite and "DİŞLİSİZ" in motTip:
    templateFile = os.environ['APPDATA'] + "\\AsnHesap\\alp\\Veriler - 10 Kişi 800 KG Dişlisiz (AKIŞ - AK3).txt"
if "13 kişi" and "1000 KG" in kapasite and "DİŞLİSİZ" in motTip:
    templateFile = os.environ['APPDATA'] + "\\AsnHesap\\alp\\Veriler - 13 Kişi 1000 KG Dişlisiz.txt"
if "17 kişi" and "1275 KG" in kapasite and "DİŞLİSİZ" in motTip:
    templateFile = os.environ['APPDATA'] + "\\AsnHesap\\alp\\Veriler - 17 Kişi 1275 KG Dişlisiz.txt"
if "21 kişi" and "1600 KG" in kapasite and "DİŞLİSİZ" in motTip:
    templateFile = os.environ['APPDATA'] + "\\AsnHesap\\alp\\Veriler - 21 Kişi 1600 KG Dişlisiz.txt"

if "10 kişi" and "800 KG" in kapasite and "Hidrolik" in motTip:
    templateFile = os.environ['APPDATA'] + "\\AsnHesap\\alp\\Veriler - 10 Kişi 800 KG Hidrolik 0.63 18.4 kW.txt"

f = open(templateFile, "r", encoding='ANSI')
lineList = f.readlines()
f.close()
# ---- templateFile read complete ----

# Write data to AsnHesap veriler.txt
f = open(os.environ['APPDATA'] + "\\AsnHesap\\veriler.txt", "w", encoding='utf-8')

lineList[0] = yapıSah + "\n"
lineList[1] = bel + "\n"
lineList[2] = mah + "\n"
lineList[3] = cadSk + "\n" # Cadde

lineList[5] = bel + "\n" # İlçe
lineList[6] = il + "\n"
lineList[7] = no + "\n"
lineList[8] = pafta + "\n"
lineList[9] = ada + "\n"
lineList[10] = parsel + "\n"
lineList[11] = "SINIF I / İNSAN ASANSÖRÜ" + "\n"
lineList[12] = asnSeriNo + "\n"
lineList[13] = date + "\n"

lineList[16] = motGüç  + "\n" # Motor gücü [kW]

lineList[32] = kuyuBoyu + "\n"

lineList[35] = durSayÜst + "\n" # Ana durak üstü durak sayısı
lineList[36] = durSayAlt + "\n" # Ana durak altı durak sayısı

lineList[40] = seyir + "\n"
lineList[41] = hız + "\n"

lineList[47] = kabDer + "\n"
lineList[48] = kabGen + "\n"

lineList[59] = rayKapı + "\n" 


f.writelines(lineList)
f.close()